# AeroIndustrial build status

This snapshot is **build-ready source**, but it is not labelled as a verified release artifact unless Gradle can resolve the actual Minecraft/NeoForge dependencies and a runtime launch has been completed.

Target stack:

- Minecraft 1.21.1
- Java 21
- NeoForge 21.1.250
- Create 6.0.10-280
- Create Aeronautics 1.3.2
- Sable 2.0.6
- GregTech CEu Modern 7.0.2

Run:

```text
./gradlew build
./gradlew runClient
./gradlew runServer
```

The repository contains bootstrap `gradlew` scripts that download Gradle 8.12.1 when a system Gradle installation is absent. The current authoring sandbox cannot access external package repositories, so it cannot perform the final dependency resolution or Minecraft runtime test itself.
