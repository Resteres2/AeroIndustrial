# AeroIndustrial architecture

## Layers

`AeroIndustrial` → registration/configuration

`AeroMachineBlock` → directional machine block + GUI entry point

`AeroMachineBlockEntity` → AeroFlux state, processing, persistence and optional bridges

`OptionalModCompat` → runtime detection and reflection-only Create/GT/Sable dispatch

`SableThrusterBridge` → isolated typed Sable API bridge, only loaded when explicitly requested

## Why the Sable bridge is isolated

Aeronautics is built on the Sable moving-sub-level/physics stack. Directly implementing a Sable interface in the core block entity would make the core class depend on Sable at class-load time and defeat the optional-dependency requirement. The bridge therefore remains in a separate class and is invoked through reflection.

## Why AeroFlux is separate

Using FE or EU directly would turn the project into another energy wrapper. AeroFlux deliberately combines an input's magnitude (RPM/industrial energy) with storage, processing demand, overload and mobile-structure state.

## Data-driven content

Crafting recipes use the 1.21.1 recipe schema. GregTech-specific recipe content is guarded with `neoforge:mod_loaded`, so a missing GTCEu registry entry does not invalidate the base recipe set.
