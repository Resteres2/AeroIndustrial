package dev.anton.aeroindustrial.block;

public enum MachineKind {
    FLUX_LATTICE("flux_lattice", 1200, 1.00),
    TORQUE_RESONATOR("torque_resonator", 1600, 1.20),
    PHASE_REFINER("phase_refiner", 2400, 1.35),
    VECTOR_COMPRESSOR("vector_compressor", 3200, 1.50),
    SKY_RELAY("sky_relay", 5000, 0.90),
    INERTIAL_ACCUMULATOR("inertial_accumulator", 8000, 0.75),
    AERO_FORGE("aero_forge", 4500, 1.80),
    ATMOSPHERIC_CONDENSER("atmospheric_condenser", 2800, 1.15),
    MOBILE_REFINERY("mobile_refinery", 6000, 1.65),
    VECTOR_THRUSTER("vector_thruster", 10000, 2.20);

    private final String id;
    private final int capacity;
    private final double efficiency;

    MachineKind(String id, int capacity, double efficiency) {
        this.id = id;
        this.capacity = capacity;
        this.efficiency = efficiency;
    }

    public String id() { return id; }
    public int capacity() { return capacity; }
    public double efficiency() { return efficiency; }
}
