package dev.anton.aeroindustrial.client;

import dev.anton.aeroindustrial.AeroIndustrial;
import dev.anton.aeroindustrial.registry.AeroMenus;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

@EventBusSubscriber(modid = AeroIndustrial.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class AeroClientEvents {
    private AeroClientEvents() {}

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(AeroMenus.MACHINE.get(), AeroMachineScreen::new);
    }
}
