package dev.anton.aeroindustrial.compat;

import dev.anton.aeroindustrial.blockentity.AeroMachineBlockEntity;
import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.api.physics.handle.RigidBodyHandle;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;
import org.joml.Vector3d;

/** Loaded only through reflection when Sable is present. This is the physical bridge for Vector Thruster. */
public final class SableThrusterBridge {
    private SableThrusterBridge() {}

    public static void apply(AeroMachineBlockEntity machine) {
        if (!(machine.getLevel() instanceof ServerLevel level)) return;
        var sub = Sable.HELPER.getContaining(machine);
        if (!(sub instanceof ServerSubLevel serverSub)) return;
        RigidBodyHandle handle = RigidBodyHandle.of(serverSub);
        if (handle == null || !handle.isValid()) return;
        BlockState state = machine.getBlockState();
        Direction dir = state.getValue(net.minecraft.world.level.block.state.properties.BlockStateProperties.FACING);
        double strength = Math.max(0.0, machine.flux() / (double)Math.max(1, machine.capacity()));
        strength *= 0.8;
        Vector3d impulse = new Vector3d(dir.getStepX(), dir.getStepY(), dir.getStepZ()).mul(strength);
        Vector3d point = new Vector3d(machine.getBlockPos().getX(), machine.getBlockPos().getY(), machine.getBlockPos().getZ());
        handle.applyImpulseAtPoint(point, impulse);
    }
}
