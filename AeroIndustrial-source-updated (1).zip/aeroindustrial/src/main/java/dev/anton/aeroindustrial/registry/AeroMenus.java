package dev.anton.aeroindustrial.registry;

import dev.anton.aeroindustrial.AeroIndustrial;
import dev.anton.aeroindustrial.menu.AeroMachineMenu;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.flag.FeatureFlags;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class AeroMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU, AeroIndustrial.MOD_ID);
    public static final DeferredHolder<MenuType<?>, MenuType<AeroMachineMenu>> MACHINE = MENUS.register("aero_machine", () -> new MenuType<>(AeroMachineMenu::new, FeatureFlags.DEFAULT_FLAGS));
    private AeroMenus() {}
}
