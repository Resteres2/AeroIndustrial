package dev.anton.aeroindustrial.registry;

import dev.anton.aeroindustrial.AeroIndustrial;
import dev.anton.aeroindustrial.block.AeroMachineBlock;
import dev.anton.aeroindustrial.block.MachineKind;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class AeroBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(AeroIndustrial.MOD_ID);

    public static final DeferredBlock<Block> FLUX_LATTICE = machine(MachineKind.FLUX_LATTICE);
    public static final DeferredBlock<Block> TORQUE_RESONATOR = machine(MachineKind.TORQUE_RESONATOR);
    public static final DeferredBlock<Block> PHASE_REFINER = machine(MachineKind.PHASE_REFINER);
    public static final DeferredBlock<Block> VECTOR_COMPRESSOR = machine(MachineKind.VECTOR_COMPRESSOR);
    public static final DeferredBlock<Block> SKY_RELAY = machine(MachineKind.SKY_RELAY);
    public static final DeferredBlock<Block> INERTIAL_ACCUMULATOR = machine(MachineKind.INERTIAL_ACCUMULATOR);
    public static final DeferredBlock<Block> AERO_FORGE = machine(MachineKind.AERO_FORGE);
    public static final DeferredBlock<Block> ATMOSPHERIC_CONDENSER = machine(MachineKind.ATMOSPHERIC_CONDENSER);
    public static final DeferredBlock<Block> MOBILE_REFINERY = machine(MachineKind.MOBILE_REFINERY);
    public static final DeferredBlock<Block> VECTOR_THRUSTER = machine(MachineKind.VECTOR_THRUSTER);

    public static final DeferredBlock<Block> AEROFLUX_CAPACITOR = simple("aeroflux_capacitor", 4.0f);
    public static final DeferredBlock<Block> MOBILE_DOCK = simple("mobile_dock", 5.0f);
    public static final DeferredBlock<Block> PRESSURE_LATTICE = simple("pressure_lattice", 3.0f);
    public static final DeferredBlock<Block> AERONAUTICAL_CONDUIT = simple("aeronautical_conduit", 2.5f);
    public static final DeferredBlock<Block> VECTOR_FRAME = simple("vector_frame", 3.0f);

    private static DeferredBlock<Block> machine(MachineKind kind) {
        return BLOCKS.register(kind.id(), () -> new AeroMachineBlock(
                BlockBehaviour.Properties.ofFullCopy(Blocks.IRON_BLOCK).strength(4.0f, 8.0f), kind));
    }

    private static DeferredBlock<Block> simple(String id, float strength) {
        return BLOCKS.registerSimpleBlock(id, BlockBehaviour.Properties.ofFullCopy(Blocks.IRON_BLOCK).strength(strength, 8.0f));
    }

    private AeroBlocks() {}
}
