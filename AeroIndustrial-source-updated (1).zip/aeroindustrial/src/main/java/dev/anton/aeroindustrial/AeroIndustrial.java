package dev.anton.aeroindustrial;

import dev.anton.aeroindustrial.config.AeroConfig;
import dev.anton.aeroindustrial.registry.AeroBlockEntities;
import dev.anton.aeroindustrial.registry.AeroCreativeTab;
import dev.anton.aeroindustrial.registry.AeroBlocks;
import dev.anton.aeroindustrial.registry.AeroItems;
import dev.anton.aeroindustrial.registry.AeroMenus;
import dev.anton.aeroindustrial.registry.AeroRecipes;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(AeroIndustrial.MOD_ID)
public final class AeroIndustrial {
    public static final String MOD_ID = "aeroindustrial";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public AeroIndustrial(ModContainer container) {
        AeroBlocks.BLOCKS.register(container.getEventBus());
        AeroCreativeTab.TABS.register(container.getEventBus());
        AeroItems.ITEMS.register(container.getEventBus());
        AeroBlockEntities.BLOCK_ENTITY_TYPES.register(container.getEventBus());
        AeroMenus.MENUS.register(container.getEventBus());
        AeroRecipes.SERIALIZERS.register(container.getEventBus());
        container.registerConfig(ModConfig.Type.SERVER, AeroConfig.SERVER_SPEC);
        LOGGER.info("AeroIndustrial initialized. Optional bridges are discovered at runtime.");
    }
}
