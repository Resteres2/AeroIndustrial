package dev.anton.aeroindustrial.blockentity;

import dev.anton.aeroindustrial.block.MachineKind;
import dev.anton.aeroindustrial.compat.OptionalModCompat;
import dev.anton.aeroindustrial.config.AeroConfig;
import dev.anton.aeroindustrial.menu.AeroMachineMenu;
import dev.anton.aeroindustrial.registry.AeroBlockEntities;
import dev.anton.aeroindustrial.registry.AeroItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public class AeroMachineBlockEntity extends BaseContainerBlockEntity {
    private MachineKind kind;
    private int flux;
    private int progress;
    private int overload;
    private boolean active;
    private NonNullList<ItemStack> items = NonNullList.withSize(3, ItemStack.EMPTY);

    public AeroMachineBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state, @Nullable MachineKind kind) {
        super(type, pos, state);
        this.kind = kind != null ? kind : inferKind(state);
    }

    private MachineKind inferKind(BlockState state) {
        String id = state.getBlock().builtInRegistryHolder().key().location().getPath();
        for (MachineKind k : MachineKind.values()) if (k.id().equals(id)) return k;
        return MachineKind.FLUX_LATTICE;
    }

    public MachineKind kind() { return kind; }
    public int flux() { return flux; }
    public int capacity() { return kind.capacity(); }
    public int progress() { return progress; }
    public boolean active() { return active; }
    public int overload() { return overload; }

    public static void tick(Level level, BlockPos pos, BlockState state, AeroMachineBlockEntity be) {
        if (!level.isClientSide) be.tickServer(level, pos);
    }

    private void tickServer(Level level, BlockPos pos) {
        int kinetic = (int)Math.abs(neighborKineticSpeed(level, pos));
        int generated = kinetic * AeroConfig.KINETIC_RPM_FACTOR.get();
        if (kind == MachineKind.FLUX_LATTICE || kind == MachineKind.TORQUE_RESONATOR || kind == MachineKind.SKY_RELAY) {
            addFlux(Math.min(generated, 80));
        }
        long gtEnergy = consumeNeighborGregTechEnergy(level, pos, Math.max(100L, demand() * 100L));
        if (gtEnergy > 0) addFlux((int)Math.min(80, Math.max(1L, gtEnergy / 100L)));
        if (kind == MachineKind.SKY_RELAY && OptionalModCompat.onMovingStructure(level, pos)) addFlux(10);
        if (kind == MachineKind.VECTOR_THRUSTER && flux > demand()) OptionalModCompat.tryApplyThruster(this);

        int demand = demand();
        active = false;
        if (flux >= demand && hasValidInput()) {
            flux -= demand;
            progress++;
            active = true;
            if (progress >= 40) { progress = 0; process(); }
        } else if (demand > 0 && hasValidInput()) {
            overload = Math.min(AeroConfig.OVERLOAD_LIMIT.get(), overload + 1);
        } else {
            overload = Math.max(0, overload - 1);
        }
        if (overload >= AeroConfig.OVERLOAD_LIMIT.get()) {
            flux = 0; overload = 0; progress = 0;
        }
        if (level.getGameTime() % 10 == 0) level.sendBlockUpdated(pos, getBlockState(), getBlockState(), 3);
        setChanged();
    }

    private double neighborKineticSpeed(Level level, BlockPos pos) {
        double best = 0;
        for (var d : net.minecraft.core.Direction.values()) {
            BlockEntity n = level.getBlockEntity(pos.relative(d));
            best = Math.max(best, OptionalModCompat.readCreateSpeed(n));
        }
        return best;
    }

    private long consumeNeighborGregTechEnergy(Level level, BlockPos pos, long requested) {
        long best = 0;
        for (var d : net.minecraft.core.Direction.values()) {
            BlockEntity n = level.getBlockEntity(pos.relative(d));
            long pulled = OptionalModCompat.extractGregTechEnergy(n, requested);
            if (pulled > best) best = pulled;
            if (best >= requested) break;
        }
        return best;
    }

    private int demand() {
        return switch (kind) {
            case FLUX_LATTICE -> 2; case TORQUE_RESONATOR -> 6; case PHASE_REFINER -> 12;
            case VECTOR_COMPRESSOR -> 18; case SKY_RELAY -> 10; case INERTIAL_ACCUMULATOR -> 8;
            case AERO_FORGE -> 22; case ATMOSPHERIC_CONDENSER -> 14; case MOBILE_REFINERY -> 26;
            case VECTOR_THRUSTER -> 30;
        };
    }

    private boolean hasValidInput() {
        if (items.get(0).isEmpty()) return false;
        ItemStack out = outputFor(kind, items.get(0));
        if (out.isEmpty()) return false;
        ItemStack existing = items.get(2);
        return existing.isEmpty() || (ItemStack.isSameItemSameComponents(existing, out)
                && existing.getCount() + out.getCount() <= existing.getMaxStackSize());
    }

    private void process() {
        ItemStack in = items.get(0);
        ItemStack out = outputFor(kind, in);
        if (out.isEmpty()) return;
        if (items.get(2).isEmpty()) { items.set(2, out.copy()); in.shrink(1); }
        else if (ItemStack.isSameItemSameComponents(items.get(2), out) && items.get(2).getCount() + out.getCount() <= items.get(2).getMaxStackSize()) {
            items.get(2).grow(out.getCount()); in.shrink(1);
        }
    }

    private ItemStack outputFor(MachineKind kind, ItemStack in) {
        return switch (kind) {
            case FLUX_LATTICE -> in.is(Items.REDSTONE) ? new ItemStack(AeroItems.AEROFLUX_CRYSTAL.get()) : ItemStack.EMPTY;
            case TORQUE_RESONATOR -> in.is(Items.IRON_INGOT) ? new ItemStack(AeroItems.VECTOR_COIL.get()) : ItemStack.EMPTY;
            case PHASE_REFINER -> in.is(Items.QUARTZ) ? new ItemStack(AeroItems.PHASE_FOIL.get()) : ItemStack.EMPTY;
            case VECTOR_COMPRESSOR -> in.is(AeroItems.PHASE_FOIL.get()) ? new ItemStack(AeroItems.SKY_LATTICE.get()) : ItemStack.EMPTY;
            case SKY_RELAY -> in.is(AeroItems.SKY_LATTICE.get()) ? new ItemStack(AeroItems.RESONANCE_CELL.get()) : ItemStack.EMPTY;
            case INERTIAL_ACCUMULATOR -> in.is(AeroItems.RESONANCE_CELL.get()) ? new ItemStack(AeroItems.INERTIAL_CORE.get()) : ItemStack.EMPTY;
            case AERO_FORGE -> in.is(AeroItems.INERTIAL_CORE.get()) ? new ItemStack(AeroItems.FLUX_CONDUCTOR.get()) : ItemStack.EMPTY;
            case ATMOSPHERIC_CONDENSER -> in.is(Items.ICE) ? new ItemStack(AeroItems.PRESSURE_GEL.get()) : ItemStack.EMPTY;
            case MOBILE_REFINERY -> in.is(AeroItems.FLUX_CONDUCTOR.get()) ? new ItemStack(AeroItems.RESONANCE_CELL.get()) : ItemStack.EMPTY;
            case VECTOR_THRUSTER -> in.is(AeroItems.RESONANCE_CELL.get()) ? new ItemStack(AeroItems.VECTOR_COIL.get()) : ItemStack.EMPTY;
        };
    }

    private void addFlux(int amount) { flux = Math.min(capacity(), flux + amount); }

    public Component status() { return Component.literal(kind.id() + " | AeroFlux " + flux + "/" + capacity() + " | " + OptionalModCompat.describeEnvironment()); }

    @Override protected NonNullList<ItemStack> getItems() { return items; }
    @Override protected void setItems(NonNullList<ItemStack> items) { this.items = items; }
    @Override public int getContainerSize() { return 3; }
    @Override protected Component getDefaultName() { return Component.translatable("container.aeroindustrial." + kind.id()); }
    @Override protected AbstractContainerMenu createMenu(int syncId, Inventory inventory) { return new AeroMachineMenu(syncId, inventory, this); }
    @Override public boolean stillValid(Player player) { return !this.isRemoved() && player.distanceToSqr(worldPosition.getX()+0.5, worldPosition.getY()+0.5, worldPosition.getZ()+0.5) < 64.0; }

    @Override protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putString("Kind", kind.id()); tag.putInt("Flux", flux); tag.putInt("Progress", progress); tag.putInt("Overload", overload);
    }

    @Override protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        String k = tag.getString("Kind");
        for (MachineKind v : MachineKind.values()) if (v.id().equals(k)) kind = v;
        flux = tag.getInt("Flux"); progress = tag.getInt("Progress"); overload = tag.getInt("Overload");
    }
}
