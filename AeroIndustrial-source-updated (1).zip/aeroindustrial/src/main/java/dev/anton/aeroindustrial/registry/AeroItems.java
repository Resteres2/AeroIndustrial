package dev.anton.aeroindustrial.registry;

import dev.anton.aeroindustrial.AeroIndustrial;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class AeroItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(AeroIndustrial.MOD_ID);

    public static final DeferredItem<Item> AEROFLUX_CRYSTAL = item("aeroflux_crystal");
    public static final DeferredItem<Item> PHASE_FOIL = item("phase_foil");
    public static final DeferredItem<Item> VECTOR_COIL = item("vector_coil");
    public static final DeferredItem<Item> INERTIAL_CORE = item("inertial_core");
    public static final DeferredItem<Item> SKY_LATTICE = item("sky_lattice");
    public static final DeferredItem<Item> RESONANCE_CELL = item("resonance_cell");
    public static final DeferredItem<Item> PRESSURE_GEL = item("pressure_gel");
    public static final DeferredItem<Item> FLUX_CONDUCTOR = item("flux_conductor");

    public static final DeferredItem<BlockItem> FLUX_LATTICE_ITEM = block(AeroBlocks.FLUX_LATTICE);
    public static final DeferredItem<BlockItem> TORQUE_RESONATOR_ITEM = block(AeroBlocks.TORQUE_RESONATOR);
    public static final DeferredItem<BlockItem> PHASE_REFINER_ITEM = block(AeroBlocks.PHASE_REFINER);
    public static final DeferredItem<BlockItem> VECTOR_COMPRESSOR_ITEM = block(AeroBlocks.VECTOR_COMPRESSOR);
    public static final DeferredItem<BlockItem> SKY_RELAY_ITEM = block(AeroBlocks.SKY_RELAY);
    public static final DeferredItem<BlockItem> INERTIAL_ACCUMULATOR_ITEM = block(AeroBlocks.INERTIAL_ACCUMULATOR);
    public static final DeferredItem<BlockItem> AERO_FORGE_ITEM = block(AeroBlocks.AERO_FORGE);
    public static final DeferredItem<BlockItem> ATMOSPHERIC_CONDENSER_ITEM = block(AeroBlocks.ATMOSPHERIC_CONDENSER);
    public static final DeferredItem<BlockItem> MOBILE_REFINERY_ITEM = block(AeroBlocks.MOBILE_REFINERY);
    public static final DeferredItem<BlockItem> VECTOR_THRUSTER_ITEM = block(AeroBlocks.VECTOR_THRUSTER);
    public static final DeferredItem<BlockItem> CAPACITOR_ITEM = block(AeroBlocks.AEROFLUX_CAPACITOR);
    public static final DeferredItem<BlockItem> DOCK_ITEM = block(AeroBlocks.MOBILE_DOCK);
    public static final DeferredItem<BlockItem> PRESSURE_ITEM = block(AeroBlocks.PRESSURE_LATTICE);
    public static final DeferredItem<BlockItem> CONDUIT_ITEM = block(AeroBlocks.AERONAUTICAL_CONDUIT);
    public static final DeferredItem<BlockItem> FRAME_ITEM = block(AeroBlocks.VECTOR_FRAME);

    private static DeferredItem<Item> item(String id) {
        return ITEMS.registerSimpleItem(id, new Item.Properties().stacksTo(64));
    }

    private static DeferredItem<BlockItem> block(net.neoforged.neoforge.registries.DeferredBlock<net.minecraft.world.level.block.Block> block) {
        return ITEMS.registerSimpleBlockItem(block.getId().getPath(), block);
    }

    private AeroItems() {}
}
