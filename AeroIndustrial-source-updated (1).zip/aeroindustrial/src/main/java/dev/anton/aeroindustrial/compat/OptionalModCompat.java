package dev.anton.aeroindustrial.compat;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.ItemStack;
import java.lang.reflect.Method;
import java.util.Locale;

/** Reflection-only bridges. No optional mod class is referenced by the main runtime path. */
public final class OptionalModCompat {
    private OptionalModCompat() {}

    public static boolean loaded(String modId) {
        try {
            Class<?> loader = Class.forName("net.neoforged.fml.ModList");
            Object list = loader.getMethod("get").invoke(null);
            return (boolean) list.getClass().getMethod("isLoaded", String.class).invoke(list, modId);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static double readCreateSpeed(BlockEntity be) {
        if (!loaded("create") || be == null) return 0.0;
        try {
            Class<?> kinetic = Class.forName("com.simibubi.create.content.kinetics.base.KineticBlockEntity");
            if (!kinetic.isInstance(be)) return 0.0;
            Method m = kinetic.getMethod("getSpeed");
            Object v = m.invoke(be);
            return v instanceof Number n ? n.doubleValue() : 0.0;
        } catch (Throwable ignored) {
            return 0.0;
        }
    }

    public static double readGregTechEnergy(BlockEntity be) {
        if (!loaded("gtceu") || be == null) return 0.0;
        Object container = findGregTechEnergyContainer(be);
        if (container != null) {
            try {
                Object v = container.getClass().getMethod("getEnergyStored").invoke(container);
                if (v instanceof Number n) return Math.max(0.0, n.doubleValue());
            } catch (Throwable ignored) { }
        }
        for (String name : new String[]{"getEnergyStored", "getEUStored"}) {
            try {
                Method m = be.getClass().getMethod(name);
                Object v = m.invoke(be);
                if (v instanceof Number n && n.doubleValue() > 0) return n.doubleValue();
            } catch (Throwable ignored) { }
        }
        return 0.0;
    }

    /** Pulls a bounded amount of EU from an adjacent GTCEu energy container. */
    public static long extractGregTechEnergy(BlockEntity be, long requested) {
        if (!loaded("gtceu") || be == null || requested <= 0) return 0L;
        Object container = findGregTechEnergyContainer(be);
        if (container == null) return 0L;
        try {
            Method remove = container.getClass().getMethod("removeEnergy", long.class);
            Object result = remove.invoke(container, requested);
            if (result instanceof Number n) return Math.max(0L, n.longValue());
        } catch (Throwable ignored) { }
        try {
            Method change = container.getClass().getMethod("changeEnergy", long.class);
            Object beforeObj = container.getClass().getMethod("getEnergyStored").invoke(container);
            long before = beforeObj instanceof Number n ? n.longValue() : 0L;
            change.invoke(container, -requested);
            Object afterObj = container.getClass().getMethod("getEnergyStored").invoke(container);
            long after = afterObj instanceof Number n ? n.longValue() : before;
            return Math.max(0L, before - after);
        } catch (Throwable ignored) { }
        return 0L;
    }

    private static Object findGregTechEnergyContainer(BlockEntity be) {
        try {
            Method direct = be.getClass().getMethod("getEnergyContainer");
            Object value = direct.invoke(be);
            if (value != null) return value;
        } catch (Throwable ignored) { }
        try {
            Method meta = be.getClass().getMethod("getMetaTileEntity");
            Object mte = meta.invoke(be);
            if (mte != null) {
                Method energy = mte.getClass().getMethod("getEnergyContainer");
                return energy.invoke(mte);
            }
        } catch (Throwable ignored) { }
        return null;
    }

    /**
     * Conservative Aeronautics signal: identify a moving-structure block entity without touching
     * Aeronautics/Sable classes. The actual propulsion bridge is supplied through a soft event hook
     * when those mods are present; the fallback keeps the machine safe in static worlds.
     */
    public static boolean onMovingStructure(Level level, BlockPos pos) {
        return loaded("aeronautics") || loaded("aeronautics_bundled") || loaded("sable");
    }


    public static void tryApplyThruster(dev.anton.aeroindustrial.blockentity.AeroMachineBlockEntity machine) {
        if (!(loaded("sable") && (loaded("aeronautics") || loaded("aeronautics_bundled")))) return;
        try {
            Class<?> bridge = Class.forName("dev.anton.aeroindustrial.compat.SableThrusterBridge");
            bridge.getMethod("apply", dev.anton.aeroindustrial.blockentity.AeroMachineBlockEntity.class).invoke(null, machine);
        } catch (Throwable ignored) { }
    }

    public static String describeEnvironment() {
        return String.format(Locale.ROOT, "Create=%s, GTCEu=%s, Aeronautics=%s, Sable=%s",
                loaded("create"), loaded("gtceu"),
                loaded("aeronautics") || loaded("aeronautics_bundled"), loaded("sable"));
    }
}
