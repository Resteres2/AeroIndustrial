package dev.anton.aeroindustrial.menu;

import dev.anton.aeroindustrial.blockentity.AeroMachineBlockEntity;
import dev.anton.aeroindustrial.registry.AeroMenus;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class AeroMachineMenu extends AbstractContainerMenu {
    private final Container container;
    private final DataSlot flux = DataSlot.standalone();
    private final DataSlot capacity = DataSlot.standalone();
    private final DataSlot progress = DataSlot.standalone();
    private final DataSlot overload = DataSlot.standalone();
    private final AeroMachineBlockEntity machine;

    public AeroMachineMenu(int id, Inventory inv, Container container) {
        super(AeroMenus.MACHINE.get(), id);
        this.container = container;
        this.machine = container instanceof AeroMachineBlockEntity m ? m : null;
        checkContainerSize(container, 3);
        container.startOpen(inv.player);
        addSlot(new Slot(container, 0, 44, 35));
        addSlot(new Slot(container, 1, 80, 35));
        addSlot(new Slot(container, 2, 116, 35));
        addPlayerInventory(inv);
        addDataSlot(flux); addDataSlot(capacity); addDataSlot(progress); addDataSlot(overload);
        if (machine != null) syncDataFromMachine();
    }

    public AeroMachineMenu(int id, Inventory inv) { this(id, inv, new SimpleContainer(3)); }

    private void syncDataFromMachine() {
        flux.set(machine.flux()); capacity.set(machine.capacity()); progress.set(machine.progress()); overload.set(machine.overload());
    }

    private void addPlayerInventory(Inventory inv) {
        for (int row=0; row<3; row++) for (int col=0; col<9; col++) addSlot(new Slot(inv, col+row*9+9, 8+col*18, 84+row*18));
        for (int col=0; col<9; col++) addSlot(new Slot(inv, col, 8+col*18, 142));
    }

    @Override public void broadcastChanges() {
        if (machine != null) syncDataFromMachine();
        super.broadcastChanges();
    }

    @Override public boolean stillValid(Player player) { return container.stillValid(player); }
    @Override public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (!slot.hasItem()) return ItemStack.EMPTY;
        ItemStack copy = slot.getItem().copy();
        if (index < 3) { if (!moveItemStackTo(slot.getItem(), 3, 39, true)) return ItemStack.EMPTY; }
        else { if (!moveItemStackTo(slot.getItem(), 0, 3, false)) return ItemStack.EMPTY; }
        if (slot.getItem().isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
        return copy;
    }
    @Override public void removed(Player player) { super.removed(player); container.stopOpen(player); }

    public int fluxValue() { return flux.get(); }
    public int capacityValue() { return Math.max(1, capacity.get()); }
    public int progressValue() { return progress.get(); }
    public int overloadValue() { return overload.get(); }
    public AeroMachineBlockEntity machine() { return machine; }
}
