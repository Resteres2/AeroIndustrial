package dev.anton.aeroindustrial.config;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class AeroConfig {
    public static final ModConfigSpec SERVER_SPEC;
    public static final ModConfigSpec.IntValue BASE_AEROFLUX_CAPACITY;
    public static final ModConfigSpec.IntValue KINETIC_RPM_FACTOR;
    public static final ModConfigSpec.IntValue OVERLOAD_LIMIT;
    public static final ModConfigSpec.DoubleValue THRUSTER_FORCE;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        b.comment("AeroIndustrial server balance settings").push("energy");
        BASE_AEROFLUX_CAPACITY = b.defineInRange("baseCapacity", 10000, 100, 1000000);
        KINETIC_RPM_FACTOR = b.defineInRange("kineticRpmFactor", 2, 1, 100);
        OVERLOAD_LIMIT = b.defineInRange("overloadLimit", 100, 1, 1000);
        b.pop();
        b.comment("Aeronautics bridge").push("aeronautics");
        THRUSTER_FORCE = b.defineInRange("thrusterForce", 0.65D, 0.0D, 100.0D);
        b.pop();
        SERVER_SPEC = b.build();
    }

    private AeroConfig() {}
}
