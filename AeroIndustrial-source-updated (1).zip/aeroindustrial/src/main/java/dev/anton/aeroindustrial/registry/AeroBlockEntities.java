package dev.anton.aeroindustrial.registry;

import dev.anton.aeroindustrial.AeroIndustrial;
import dev.anton.aeroindustrial.blockentity.AeroMachineBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class AeroBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, AeroIndustrial.MOD_ID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AeroMachineBlockEntity>> MACHINE =
            BLOCK_ENTITY_TYPES.register("aero_machine", () -> BlockEntityType.Builder.of(
                    (pos, state) -> new AeroMachineBlockEntity(MACHINE.get(), pos, state, null),
                    AeroBlocks.FLUX_LATTICE.get(), AeroBlocks.TORQUE_RESONATOR.get(), AeroBlocks.PHASE_REFINER.get(),
                    AeroBlocks.VECTOR_COMPRESSOR.get(), AeroBlocks.SKY_RELAY.get(), AeroBlocks.INERTIAL_ACCUMULATOR.get(),
                    AeroBlocks.AERO_FORGE.get(), AeroBlocks.ATMOSPHERIC_CONDENSER.get(), AeroBlocks.MOBILE_REFINERY.get(),
                    AeroBlocks.VECTOR_THRUSTER.get()).build(null));

    private AeroBlockEntities() {}
}
