package dev.anton.aeroindustrial.client;

import dev.anton.aeroindustrial.menu.AeroMachineMenu;
import dev.anton.aeroindustrial.blockentity.AeroMachineBlockEntity;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public final class AeroMachineScreen extends AbstractContainerScreen<AeroMachineMenu> {
    public AeroMachineScreen(AeroMachineMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 176;
        imageHeight = 166;
    }

    @Override protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = leftPos, y = topPos;
        g.fill(x, y, x+176, y+166, 0xFF252A30);
        g.fill(x+4, y+4, x+172, y+78, 0xFF11161B);
        // Three process slots.
        for (int sx : new int[]{44,80,116}) {
            g.fill(x+sx-1, y+34, x+sx+17, y+52, 0xFF555E68);
            g.fill(x+sx, y+35, x+sx+16, y+51, 0xFF20262C);
        }
        g.fill(x+10, y+60, x+166, y+68, 0xFF0B0E12);
        int w = (int)(156.0 * menu.fluxValue() / Math.max(1, menu.capacityValue()));
            g.fill(x+10, y+60, x+10+w, y+68, 0xFF3BA6FF);
        // Player inventory area.
        g.fill(x+4, y+80, x+172, y+162, 0xFF181D22);
    }

    @Override protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(font, title, 8, 6, 0xE6EDF3, false);
        g.drawString(font, playerInventoryTitle, 8, imageHeight - 94, 0xC6CED8, false);
        String s = "AF " + menu.fluxValue() + "/" + menu.capacityValue();
        g.drawString(font, s, 10, 18, 0xA9C8E8, false);
        g.drawString(font, "P" + menu.progressValue() + "  O" + menu.overloadValue(), 10, 70, 0x9AA7B5, false);
    }
}
